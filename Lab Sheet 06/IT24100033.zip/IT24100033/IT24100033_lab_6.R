setwd("C:\\Users\\Dilki\\Desktop\\IT24100033")
##Q1
#1.
#Binomial distribution
#random variable x has binomial distribution with n=50,p=0.85

#2
dbinom(47,50,0.85)

##Q2
#1 Number  of calls received per hour

#2 Poisson distribution

#3
dpois(15,12)